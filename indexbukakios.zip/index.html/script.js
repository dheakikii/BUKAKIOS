// script.js
let selectedAmount = 0;
const fixedFee = 1250; // Biaya tetap Rp 1.250
const discountAmount = 101000; // Diskon Rp 101.000 untuk Rp 1.000.000
const specialAmount = 1000000; // Nominal khusus Rp 1.000.000

function selectAmount(amount) {
    // Menghapus pilihan sebelumnya
    const checkboxes = document.querySelectorAll('input[name="amount"]');
    checkboxes.forEach((checkbox) => {
        checkbox.checked = false;
        checkbox.parentElement.classList.remove('selected');
    });

    // Menandai pilihan yang baru
    const selectedCheckbox = document.getElementById(`amount-${amount}`);
    selectedCheckbox.checked = true;
    selectedCheckbox.parentElement.classList.add('selected');

    // Menyimpan jumlah yang dipilih
    selectedAmount = amount;
}

function showTotal() {
    // Menampilkan total
    if (selectedAmount > 0) {
        let totalWithFee = selectedAmount + fixedFee; // Tambahkan biaya tetap

        // Cek apakah nominal yang dipilih adalah Rp 1.000.000
        if (selectedAmount === specialAmount) {
            totalWithFee = 899000 + fixedFee; // Total khusus untuk Rp 1.000.000
        }
        }

        document.getElementById('totalAmount').innerHTML = `Total: Rp ${totalWithFee.toLocaleString()}`;
    } else {
        document.getElementById('totalAmount').innerHTML = 'Silakan pilih nominal pulsa.';
    }
}

// Get the operator image element
const operatorImage = document.querySelector('.operator-image');

// Add a click event listener
operatorImage.addEventListener('click', () => {
  // Your code to handle the operator click goes here. 
  // For example, you could:
  // 1. Show a popup with more details about the operator
  // 2. Redirect to a different page with more information
  // 3. Update some data based on the operator selection
  console.log("Operator image clicked!"); 
});