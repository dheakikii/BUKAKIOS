// Fungsi untuk menampilkan modal operator
function showOperatorModal(operator) {
  // Dapatkan elemen modal operator
  const operatorModal = document.getElementById("operator-modal");

  // Setel judul modal operator
  operatorModal.querySelector(".modal-title").textContent = operator;

  // Setel gambar operator
  operatorModal.querySelector(".modal-image").src = `images/${operator}.png`;

  // Setel tombol operator
  operatorModal.querySelectorAll(".modal-button").forEach(button => {
    button.addEventListener("click", () => {
      // Tutup modal operator
      operatorModal.style.display = "none";

      // Tampilkan modal nominal pulsa
      showNominalModal(operator);
    });
  });

  // Tampilkan modal operator
  operatorModal.style.display = "block";
}

// Fungsi untuk menampilkan modal nominal pulsa
function showNominalModal(operator) {
  // Dapatkan elemen modal nominal pulsa
  const nominalModal = document.getElementById("nominal-modal");

  // Setel judul modal nominal pulsa
  nominalModal.querySelector(".modal-title").textContent = `Pilih Nominal Pulsa ${operator}`;

  // Setel tombol nominal pulsa
  nominalModal.querySelectorAll(".modal-button").forEach(button => {
    button.addEventListener("click", () => {
      // Dapatkan nominal pulsa
      const nominal = button.textContent;

      // Tutup modal nominal pulsa
      nominalModal.style.display = "none";

      // Lakukan aksi pembelian pulsa (misalnya, kirim data ke server)
      console.log(`Pembelian pulsa ${operator} ${nominal}`);
    });
  });

  // Tampilkan modal nominal pulsa
  nominalModal.style.display = "block";
}

// Event listener untuk tombol operator
document.querySelectorAll(".operator-button").forEach(button => {
  button.addEventListener("click", () => {
    // Dapatkan nama operator
    const operator = button.textContent;

    // Tampilkan modal operator
    showOperatorModal(operator);
  });
});